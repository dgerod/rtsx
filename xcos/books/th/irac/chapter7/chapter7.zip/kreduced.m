%Kreduced_mutools.m   Dew Apr 23,99
% perform controller reduction using mu analysis/synthesis toolbox

Korig=pck(Ac,Bc,Cc,Dc);
[Kr,hanksv]=sysbal(Korig,0);
disp(hanksv);
statenum=size(hanksv,1);
msg=sprintf('Total number of states = %d\n',statenum);
disp(msg);

nsk = input('Enter number of states to keep: ','s');
nk = str2num(nsk);
Krd = strunc(Kr,nk);

[Ar,Br,Cr,Dr]=unpck(Krd);


